package peliha.shellfishreign;

import net.fabricmc.api.ModInitializer;

public class ShellfishReignsMod implements ModInitializer {

    public static final String MOD_ID = "shellfishreign";

    @Override
    public void onInitialize() {
        // This is the body of the method
        peliha.shellfishreign.item.ModItems.registerModItems();

        // Optional: just for confirmation in the console
        System.out.println("Shellfish Reigns mod initialized!");
    }
}
