package peliha.shellfishreign.item;

import peliha.shellfishreign.ShellfishReignsMod;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModItems {

    // Register Crab Claw item
    public static final Item CRAB_CLAW = registerItem("crab_claw",
            new Item(new FabricItemSettings()));

    // Helper method for registering items
    private static Item registerItem(String name, Item item) {
        return Registry.register(Registries.ITEM, new Identifier(ShellfishReignsMod.MOD_ID, name), item);
    }

    // Called from main mod class
    public static void registerModItems() {
        System.out.println("Registering items for " + ShellfishReignsMod.MOD_ID);
    }
}
